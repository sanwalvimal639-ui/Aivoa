import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import * as api from '../api/api';

// --- Async thunks ---------------------------------------------------------

export const runAiAnalysisFromText = createAsyncThunk(
  'complaints/analyzeText',
  async (rawText, { rejectWithValue }) => {
    try {
      return await api.analyzeText(rawText);
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || err.message);
    }
  }
);

export const runAiAnalysisFromFile = createAsyncThunk(
  'complaints/analyzeFile',
  async (file, { rejectWithValue }) => {
    try {
      return await api.analyzeFile(file);
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || err.message);
    }
  }
);

export const submitComplaint = createAsyncThunk(
  'complaints/submit',
  async (payload, { rejectWithValue }) => {
    try {
      return await api.createComplaint(payload);
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || err.message);
    }
  }
);

export const fetchComplaints = createAsyncThunk(
  'complaints/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      return await api.listComplaints();
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || err.message);
    }
  }
);

export const changeComplaintStatus = createAsyncThunk(
  'complaints/changeStatus',
  async ({ id, status }, { rejectWithValue }) => {
    try {
      return await api.updateStatus(id, status);
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || err.message);
    }
  }
);

// --- Slice -----------------------------------------------------------------

const initialState = {
  list: [],
  selectedId: null,

  // The "Log Customer Complaint" form, pre-fillable by the AI Copilot
  form: {
    customer_name: '',
    product_name: '',
    product_type: '',
    batch_number: '',
    complaint_text: '',
    source_channel: 'manual',
  },

  // AI Copilot Risk Assessment panel state
  aiResult: null,
  aiLoading: false,
  aiError: null,

  listLoading: false,
  submitLoading: false,
  submitError: null,
};

const complaintsSlice = createSlice({
  name: 'complaints',
  initialState,
  reducers: {
    updateFormField(state, action) {
      const { field, value } = action.payload;
      state.form[field] = value;
    },
    resetForm(state) {
      state.form = initialState.form;
      state.aiResult = null;
      state.aiError = null;
    },
    selectComplaint(state, action) {
      state.selectedId = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // --- AI analysis (text) ---
      .addCase(runAiAnalysisFromText.pending, (state) => {
        state.aiLoading = true;
        state.aiError = null;
      })
      .addCase(runAiAnalysisFromText.fulfilled, (state, action) => {
        state.aiLoading = false;
        state.aiResult = action.payload;
        applyAiResultToForm(state, action.payload, 'prompt');
      })
      .addCase(runAiAnalysisFromText.rejected, (state, action) => {
        state.aiLoading = false;
        state.aiError = action.payload || 'AI analysis failed';
      })

      // --- AI analysis (file) ---
      .addCase(runAiAnalysisFromFile.pending, (state) => {
        state.aiLoading = true;
        state.aiError = null;
      })
      .addCase(runAiAnalysisFromFile.fulfilled, (state, action) => {
        state.aiLoading = false;
        state.aiResult = action.payload;
        applyAiResultToForm(state, action.payload, action.payload._source_channel || 'pdf');
      })
      .addCase(runAiAnalysisFromFile.rejected, (state, action) => {
        state.aiLoading = false;
        state.aiError = action.payload || 'AI analysis failed';
      })

      // --- Submit complaint ---
      .addCase(submitComplaint.pending, (state) => {
        state.submitLoading = true;
        state.submitError = null;
      })
      .addCase(submitComplaint.fulfilled, (state, action) => {
        state.submitLoading = false;
        state.list.unshift(action.payload);
        state.form = initialState.form;
        state.aiResult = null;
      })
      .addCase(submitComplaint.rejected, (state, action) => {
        state.submitLoading = false;
        state.submitError = action.payload || 'Failed to submit complaint';
      })

      // --- List ---
      .addCase(fetchComplaints.pending, (state) => {
        state.listLoading = true;
      })
      .addCase(fetchComplaints.fulfilled, (state, action) => {
        state.listLoading = false;
        state.list = action.payload;
      })
      .addCase(fetchComplaints.rejected, (state) => {
        state.listLoading = false;
      })

      // --- Status change ---
      .addCase(changeComplaintStatus.fulfilled, (state, action) => {
        const idx = state.list.findIndex((c) => c.id === action.payload.id);
        if (idx !== -1) state.list[idx] = action.payload;
      });
  },
});

function applyAiResultToForm(state, aiResult, sourceChannel) {
  // Pre-fill the Log Customer Complaint form from the AI Copilot's
  // extracted fields, without clobbering anything the user already typed.
  state.form.customer_name = aiResult.customer_name || state.form.customer_name;
  state.form.product_name = aiResult.product_name || state.form.product_name;
  state.form.product_type = aiResult.product_type || state.form.product_type;
  state.form.batch_number = aiResult.batch_number || state.form.batch_number;
  state.form.complaint_text = aiResult.complaint_text || state.form.complaint_text;
  state.form.source_channel = sourceChannel;
}

export const { updateFormField, resetForm, selectComplaint } = complaintsSlice.actions;
export default complaintsSlice.reducer;
