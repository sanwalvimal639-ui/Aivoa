import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:8000';

const client = axios.create({ baseURL: API_BASE });

// AI Copilot: analyze typed/pasted text (no DB write yet)
export const analyzeText = (rawText) =>
  client.post('/complaints/analyze', { raw_text: rawText }).then((r) => r.data);

// AI Copilot: analyze an uploaded PDF/email (no DB write yet)
export const analyzeFile = (file) => {
  const form = new FormData();
  form.append('file', file);
  return client
    .post('/complaints/analyze-file', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    .then((r) => r.data);
};

// Persist the (possibly edited) complaint
export const createComplaint = (payload) =>
  client.post('/complaints', payload).then((r) => r.data);

export const listComplaints = () =>
  client.get('/complaints').then((r) => r.data);

export const getComplaint = (id) =>
  client.get(`/complaints/${id}`).then((r) => r.data);

export const updateStatus = (id, status) =>
  client.patch(`/complaints/${id}/status`, { status }).then((r) => r.data);
