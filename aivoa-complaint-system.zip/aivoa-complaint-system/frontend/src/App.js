import React from 'react';
import ComplaintIntake from './components/ComplaintIntake';
import ComplaintForm from './components/ComplaintForm';
import RiskAssessmentPanel from './components/RiskAssessmentPanel';
import ComplaintList from './components/ComplaintList';

export default function App() {
  return (
    <div className="app-shell">
      <div className="app-header">
        <div>
          <h1>AIVOA — Customer Complaint Management System</h1>
          <div className="subtitle">AI-powered complaint intake &amp; risk assessment for pharmaceutical manufacturing (API / FDF)</div>
        </div>
      </div>

      <div className="grid-two-col">
        <div>
          <ComplaintIntake />
          <ComplaintForm />
          <ComplaintList />
        </div>
        <div>
          <RiskAssessmentPanel />
        </div>
      </div>
    </div>
  );
}
