import React from 'react';
import { useSelector } from 'react-redux';

const badgeClass = (level) => {
  switch ((level || '').toLowerCase()) {
    case 'low': return 'badge badge-low';
    case 'medium': return 'badge badge-medium';
    case 'high': return 'badge badge-high';
    case 'critical': return 'badge badge-critical';
    default: return 'badge';
  }
};

/**
 * The "AI Copilot Risk Assessment" panel called out explicitly in the
 * assignment's deliverables — shows every output of the LangGraph agent:
 * risk classification, completeness check, duplicate detection, root cause
 * suggestion, CAPA suggestion, and a one-line summary.
 */
export default function RiskAssessmentPanel() {
  const { aiResult, aiLoading } = useSelector((s) => s.complaints);

  return (
    <div className="card">
      <h2>AI Copilot Risk Assessment</h2>

      {aiLoading && <div className="ai-panel-empty">Running LangGraph agent…</div>}

      {!aiLoading && !aiResult && (
        <div className="ai-panel-empty">
          Run the AI Copilot on a complaint prompt or uploaded document to see
          the risk assessment here.
        </div>
      )}

      {!aiLoading && aiResult && (
        <>
          <div className="ai-field">
            <div className="k">Risk Level</div>
            <div className="v">
              <span className={badgeClass(aiResult.risk_level)}>{aiResult.risk_level || 'Unknown'}</span>
            </div>
          </div>

          <div className="ai-field">
            <div className="k">Rationale</div>
            <div className="v">{aiResult.risk_rationale || '—'}</div>
          </div>

          <div className="ai-field">
            <div className="k">Completeness Score</div>
            <div className="v">
              {aiResult.completeness_score != null ? `${aiResult.completeness_score}%` : '—'}
              {aiResult.missing_fields?.length > 0 && (
                <div style={{ marginTop: 6 }}>
                  {aiResult.missing_fields.map((f) => (
                    <span key={f} className="missing-tag">missing: {f}</span>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="ai-field">
            <div className="k">Duplicate Check</div>
            <div className="v">
              {aiResult.possible_duplicate_of
                ? `Possible duplicate of ${aiResult.possible_duplicate_of}`
                : 'No likely duplicate found'}
            </div>
          </div>

          <div className="ai-field">
            <div className="k">Root Cause Suggestion (preliminary)</div>
            <div className="v">{aiResult.root_cause_suggestion || '—'}</div>
          </div>

          <div className="ai-field">
            <div className="k">CAPA Suggestion (preliminary)</div>
            <div className="v">{aiResult.capa_suggestion || '—'}</div>
          </div>

          <div className="ai-field">
            <div className="k">AI Summary</div>
            <div className="v">{aiResult.ai_summary || '—'}</div>
          </div>
        </>
      )}
    </div>
  );
}
