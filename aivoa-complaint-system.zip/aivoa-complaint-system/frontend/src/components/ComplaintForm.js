import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateFormField, submitComplaint, resetForm } from '../store/complaintsSlice';

/**
 * The "Log Customer Complaint" form referenced explicitly in the assignment's
 * deliverables. Gets pre-filled by the AI Copilot (via complaintsSlice) but
 * every field stays editable — the human reviewer always has final say
 * before it's persisted, matching real QMS practice.
 */
export default function ComplaintForm() {
  const dispatch = useDispatch();
  const { form, submitLoading, submitError } = useSelector((s) => s.complaints);

  const set = (field) => (e) => dispatch(updateFormField({ field, value: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.complaint_text.trim()) return;
    dispatch(submitComplaint(form));
  };

  return (
    <div className="card">
      <h2>Log Customer Complaint</h2>

      {submitError && <div className="error-banner">{String(submitError)}</div>}

      <form onSubmit={handleSubmit}>
        <label>Customer Name</label>
        <input type="text" value={form.customer_name} onChange={set('customer_name')} placeholder="Optional" />

        <label>Product Name</label>
        <input type="text" value={form.product_name} onChange={set('product_name')} placeholder="e.g. Amoxicillin 500mg" />

        <label>Product Type</label>
        <select value={form.product_type} onChange={set('product_type')}>
          <option value="">Select...</option>
          <option value="API">API (Active Pharmaceutical Ingredient)</option>
          <option value="FDF">FDF (Finished Dosage Form)</option>
        </select>

        <label>Batch Number</label>
        <input type="text" value={form.batch_number} onChange={set('batch_number')} placeholder="e.g. FDF-2201" />

        <label>Complaint Description *</label>
        <textarea
          value={form.complaint_text}
          onChange={set('complaint_text')}
          placeholder="Full complaint narrative"
          required
        />

        <div className="btn-row">
          <button type="submit" className="btn btn-primary" disabled={submitLoading}>
            {submitLoading && <span className="spinner" />}
            Submit Complaint
          </button>
          <button type="button" className="btn btn-secondary" onClick={() => dispatch(resetForm())}>
            Clear
          </button>
        </div>
      </form>
    </div>
  );
}
