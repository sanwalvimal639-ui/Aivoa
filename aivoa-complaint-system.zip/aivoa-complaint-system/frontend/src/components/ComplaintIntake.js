import React, { useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { runAiAnalysisFromText, runAiAnalysisFromFile } from '../store/complaintsSlice';

/**
 * Entry point for a new complaint: either type/paste a description (prompt)
 * or upload a PDF/email. Either path calls the AI Copilot (LangGraph agent
 * on the backend) and streams the result into the Log Customer Complaint
 * form + AI Copilot Risk Assessment panel.
 */
export default function ComplaintIntake() {
  const dispatch = useDispatch();
  const { aiLoading, aiError } = useSelector((s) => s.complaints);
  const [promptText, setPromptText] = useState('');
  const fileInputRef = useRef(null);

  const handleAnalyzePrompt = () => {
    if (!promptText.trim()) return;
    dispatch(runAiAnalysisFromText(promptText));
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) dispatch(runAiAnalysisFromFile(file));
  };

  return (
    <div className="card">
      <h2>New Complaint Intake</h2>

      {aiError && <div className="error-banner">{String(aiError)}</div>}

      <label>Describe the complaint (or paste customer email text)</label>
      <textarea
        placeholder="e.g. Customer reports discoloration in Batch FDF-2201 of Amoxicillin 500mg tablets received on..."
        value={promptText}
        onChange={(e) => setPromptText(e.target.value)}
      />

      <div className="btn-row">
        <button
          className="btn btn-primary"
          disabled={aiLoading || !promptText.trim()}
          onClick={handleAnalyzePrompt}
        >
          {aiLoading && <span className="spinner" />}
          Run AI Copilot
        </button>
        <button className="btn btn-secondary" onClick={() => fileInputRef.current.click()} disabled={aiLoading}>
          Upload PDF / Email
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.eml,.txt"
          style={{ display: 'none' }}
          onChange={handleFileChange}
        />
      </div>

      <div className="file-drop" onClick={() => fileInputRef.current.click()}>
        Click to upload a complaint PDF or email (.pdf, .eml, .txt) — sample files in{' '}
        <code>sample_complaints/</code>
      </div>
    </div>
  );
}
