import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchComplaints, changeComplaintStatus, selectComplaint } from '../store/complaintsSlice';

const STATUS_OPTIONS = ['New', 'Under Review', 'Investigation', 'CAPA Proposed', 'Closed'];

const badgeClass = (level) => {
  switch ((level || '').toLowerCase()) {
    case 'low': return 'badge badge-low';
    case 'medium': return 'badge badge-medium';
    case 'high': return 'badge badge-high';
    case 'critical': return 'badge badge-critical';
    default: return 'badge';
  }
};

/** QMS-style complaint log — every submitted complaint with its AI risk
 * classification and a status dropdown for moving it through the
 * New → Under Review → Investigation → CAPA Proposed → Closed lifecycle. */
export default function ComplaintList() {
  const dispatch = useDispatch();
  const { list, listLoading, selectedId } = useSelector((s) => s.complaints);

  useEffect(() => {
    dispatch(fetchComplaints());
  }, [dispatch]);

  return (
    <div className="card">
      <h2>Complaint Log ({list.length})</h2>

      {listLoading && <div className="ai-panel-empty">Loading…</div>}
      {!listLoading && list.length === 0 && (
        <div className="ai-panel-empty">No complaints logged yet.</div>
      )}

      {list.map((c) => (
        <div
          key={c.id}
          className="complaint-row"
          onClick={() => dispatch(selectComplaint(c.id === selectedId ? null : c.id))}
        >
          <div className="top-line">
            <span>{c.complaint_number} — {c.product_name || 'Unknown product'}</span>
            <span className={badgeClass(c.risk_level)}>{c.risk_level || '—'}</span>
          </div>
          <div className="meta">
            {c.ai_summary || c.complaint_text.slice(0, 90)}
          </div>

          {selectedId === c.id && (
            <div style={{ marginTop: 10 }} onClick={(e) => e.stopPropagation()}>
              <label style={{ marginTop: 0 }}>Status</label>
              <select
                value={c.status}
                onChange={(e) => dispatch(changeComplaintStatus({ id: c.id, status: e.target.value }))}
              >
                {STATUS_OPTIONS.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
              {c.root_cause_suggestion && (
                <p style={{ fontSize: 12.5, marginTop: 8, color: '#475467' }}>
                  <strong>Root cause suggestion:</strong> {c.root_cause_suggestion}
                </p>
              )}
              {c.capa_suggestion && (
                <p style={{ fontSize: 12.5, color: '#475467' }}>
                  <strong>CAPA suggestion:</strong> {c.capa_suggestion}
                </p>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
