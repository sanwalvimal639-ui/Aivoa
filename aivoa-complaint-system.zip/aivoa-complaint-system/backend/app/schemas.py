"""Pydantic schemas — the contract between frontend and backend."""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel


class ComplaintCreate(BaseModel):
    customer_name: Optional[str] = None
    product_name: Optional[str] = None
    product_type: Optional[str] = None       # "API" | "FDF"
    batch_number: Optional[str] = None
    complaint_text: str                       # required — the narrative
    source_channel: Optional[str] = "manual"  # manual | pdf | email | prompt


class RiskAssessmentOut(BaseModel):
    risk_level: Optional[str]
    risk_rationale: Optional[str]
    completeness_score: Optional[float]
    missing_fields: Optional[List[str]] = []
    ai_summary: Optional[str]
    root_cause_suggestion: Optional[str]
    capa_suggestion: Optional[str]
    possible_duplicate_of: Optional[str]


class ComplaintOut(BaseModel):
    id: str
    complaint_number: str
    customer_name: Optional[str]
    product_name: Optional[str]
    product_type: Optional[str]
    batch_number: Optional[str]
    complaint_text: str
    source_channel: str
    status: str
    risk_level: Optional[str]
    risk_rationale: Optional[str]
    completeness_score: Optional[float]
    ai_summary: Optional[str]
    root_cause_suggestion: Optional[str]
    capa_suggestion: Optional[str]
    possible_duplicate_of: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class StatusUpdate(BaseModel):
    status: str


class ExtractedTextIn(BaseModel):
    """Used by the /analyze endpoint that runs the AI Copilot before the
    complaint is actually logged — this is what powers the 'Log Customer
    Complaint form gets pre-filled by AI' part of the demo."""
    raw_text: str
