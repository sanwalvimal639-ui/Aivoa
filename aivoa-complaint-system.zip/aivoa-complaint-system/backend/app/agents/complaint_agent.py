"""
LangGraph agent: the "AI Copilot" that turns raw complaint text (typed,
or extracted from an uploaded PDF/email) into a structured, risk-assessed
complaint record ready to populate the Log Customer Complaint form.

Graph shape:

    extract_fields ─▶ completeness_check ─▶ risk_classification
                                                     │
                                                     ▼
                                       duplicate_check ─▶ root_cause_and_capa ─▶ summarize ─▶ END

Each node is a plain Python function that reads/writes a shared TypedDict
state. This mirrors the workflow the demo video walks through: user input →
AI extraction/classification → populated form + AI Copilot Risk Assessment
panel.
"""
from typing import TypedDict, Optional, List
from langgraph.graph import StateGraph, END

from app.agents.groq_client import call_llm_json, PRIMARY_MODEL, CONTEXT_MODEL


class ComplaintAgentState(TypedDict, total=False):
    raw_text: str                      # input: typed prompt or text extracted from PDF/email
    existing_complaints: List[dict]     # recent complaints, for duplicate detection

    # extracted / structured fields
    customer_name: Optional[str]
    product_name: Optional[str]
    product_type: Optional[str]
    batch_number: Optional[str]
    complaint_text: Optional[str]

    # AI Copilot outputs
    completeness_score: Optional[float]
    missing_fields: List[str]
    risk_level: Optional[str]
    risk_rationale: Optional[str]
    possible_duplicate_of: Optional[str]
    root_cause_suggestion: Optional[str]
    capa_suggestion: Optional[str]
    ai_summary: Optional[str]


# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------

def extract_fields(state: ComplaintAgentState) -> ComplaintAgentState:
    """Pulls structured fields (customer, product, batch, product type)
    out of unstructured complaint text — the same job a QMS coordinator
    does by hand when a complaint comes in via email or a scanned form."""
    system = (
        "You are a pharmaceutical QMS complaint-intake assistant. Extract structured "
        "fields from the complaint text. Reply with ONLY a JSON object with keys: "
        "customer_name, product_name, product_type (must be exactly 'API' or 'FDF' or null), "
        "batch_number, complaint_text (a clean one-paragraph restatement of the complaint). "
        "Use null for any field you cannot confidently find. Do not invent data."
    )
    result = call_llm_json(system, state["raw_text"], model=PRIMARY_MODEL)
    state["customer_name"] = result.get("customer_name")
    state["product_name"] = result.get("product_name")
    state["product_type"] = result.get("product_type")
    state["batch_number"] = result.get("batch_number")
    state["complaint_text"] = result.get("complaint_text") or state["raw_text"]
    return state


def completeness_check(state: ComplaintAgentState) -> ComplaintAgentState:
    """Bonus feature: Complaint Completeness Checker.
    Flags which fields a real QMS intake form requires but weren't provided,
    so the human reviewer knows what to follow up on with the customer."""
    required = ["customer_name", "product_name", "product_type", "batch_number", "complaint_text"]
    missing = [f for f in required if not state.get(f)]
    score = round(100 * (len(required) - len(missing)) / len(required), 1)
    state["completeness_score"] = score
    state["missing_fields"] = missing
    return state


def risk_classification(state: ComplaintAgentState) -> ComplaintAgentState:
    """AI Risk Classification — the headline 'AI Copilot Risk Assessment' feature.
    Considers patient-safety impact, not just complaint severity in isolation,
    which is how real QMS risk triage works (adverse event > quality defect > cosmetic)."""
    system = (
        "You are a pharmaceutical quality risk-assessment assistant. Classify the patient-safety "
        "risk of this customer complaint. Consider: potential for patient harm, whether it suggests "
        "a GMP deviation, and whether it could indicate an adverse event requiring regulatory reporting. "
        "Reply with ONLY a JSON object with keys: risk_level (exactly one of 'Low','Medium','High','Critical') "
        "and risk_rationale (2-3 sentences explaining why, in plain language a QMS reviewer would write)."
    )
    result = call_llm_json(system, state.get("complaint_text", state["raw_text"]), model=PRIMARY_MODEL)
    state["risk_level"] = result.get("risk_level")
    state["risk_rationale"] = result.get("risk_rationale")
    return state


def duplicate_check(state: ComplaintAgentState) -> ComplaintAgentState:
    """Bonus feature: Duplicate Complaint Detection.
    Compares against a short list of recent complaints (passed in by the caller)
    rather than the whole DB, to keep prompts small — a real system would do a
    cheap vector/embedding pre-filter before this LLM pass."""
    existing = state.get("existing_complaints") or []
    if not existing:
        state["possible_duplicate_of"] = None
        return state

    system = (
        "You are checking whether a new pharmaceutical complaint is a likely duplicate of any "
        "recent complaint. Compare product, batch number, and issue description. "
        "Reply with ONLY a JSON object: {\"duplicate_complaint_number\": <string or null>, "
        "\"reason\": <short string>}. Only flag a duplicate if you're reasonably confident "
        "(same product/batch and same underlying issue)."
    )
    user = (
        f"NEW COMPLAINT:\n{state.get('complaint_text', state['raw_text'])}\n\n"
        f"RECENT COMPLAINTS:\n" + "\n".join(
            f"- [{c.get('complaint_number')}] product={c.get('product_name')} "
            f"batch={c.get('batch_number')} text={c.get('complaint_text')}"
            for c in existing
        )
    )
    result = call_llm_json(system, user, model=PRIMARY_MODEL)
    state["possible_duplicate_of"] = result.get("duplicate_complaint_number")
    return state


def root_cause_and_capa(state: ComplaintAgentState) -> ComplaintAgentState:
    """Bonus features: Root Cause Recommendation + CAPA Recommendation.
    Uses the larger context model since this benefits from more reasoning depth."""
    system = (
        "You are a pharmaceutical quality assurance expert supporting root-cause and CAPA "
        "(Corrective and Preventive Action) drafting for a customer complaint. This is a "
        "PRELIMINARY, AI-generated suggestion for a human QA reviewer to validate — not a final "
        "determination. Reply with ONLY a JSON object with keys: "
        "root_cause_suggestion (1-2 sentences, hypothesis only, hedge appropriately) and "
        "capa_suggestion (1-2 sentences, a plausible corrective/preventive action)."
    )
    result = call_llm_json(system, state.get("complaint_text", state["raw_text"]), model=CONTEXT_MODEL)
    state["root_cause_suggestion"] = result.get("root_cause_suggestion")
    state["capa_suggestion"] = result.get("capa_suggestion")
    return state


def summarize(state: ComplaintAgentState) -> ComplaintAgentState:
    """Bonus feature: Complaint Summary — a one-line summary for the complaint list view."""
    system = (
        "Summarize this pharmaceutical customer complaint in ONE short sentence (under 20 words), "
        "suitable for a complaint list table. Reply with ONLY a JSON object: {\"summary\": <string>}."
    )
    result = call_llm_json(system, state.get("complaint_text", state["raw_text"]), model=PRIMARY_MODEL)
    state["ai_summary"] = result.get("summary")
    return state


# ---------------------------------------------------------------------------
# Graph assembly
# ---------------------------------------------------------------------------

def build_graph():
    graph = StateGraph(ComplaintAgentState)

    graph.add_node("extract_fields", extract_fields)
    graph.add_node("completeness_check", completeness_check)
    graph.add_node("risk_classification", risk_classification)
    graph.add_node("duplicate_check", duplicate_check)
    graph.add_node("root_cause_and_capa", root_cause_and_capa)
    graph.add_node("summarize", summarize)

    graph.set_entry_point("extract_fields")
    graph.add_edge("extract_fields", "completeness_check")
    graph.add_edge("completeness_check", "risk_classification")
    graph.add_edge("risk_classification", "duplicate_check")
    graph.add_edge("duplicate_check", "root_cause_and_capa")
    graph.add_edge("root_cause_and_capa", "summarize")
    graph.add_edge("summarize", END)

    return graph.compile()


_compiled_graph = None


def get_compiled_graph():
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_graph()
    return _compiled_graph


def run_complaint_agent(raw_text: str, existing_complaints: Optional[List[dict]] = None) -> dict:
    """Entry point used by the FastAPI routes."""
    graph = get_compiled_graph()
    initial_state: ComplaintAgentState = {
        "raw_text": raw_text,
        "existing_complaints": existing_complaints or [],
    }
    final_state = graph.invoke(initial_state)
    return dict(final_state)
