"""
Lightweight document text extraction for uploaded complaint sources.

Per the assignment, production-grade OCR/parsing is explicitly NOT required —
this just needs to get raw text out of a PDF or .eml/.txt email so the
LangGraph agent has something to work with.
"""
from io import BytesIO
from pypdf import PdfReader


def extract_text_from_pdf(file_bytes: bytes) -> str:
    reader = PdfReader(BytesIO(file_bytes))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages).strip()


def extract_text_from_email(file_bytes: bytes) -> str:
    """Handles plain .txt/.eml-style text. Good enough for demo emails —
    no MIME/attachment parsing, per the 'not production-grade' note."""
    try:
        return file_bytes.decode("utf-8", errors="ignore").strip()
    except Exception:
        return file_bytes.decode("latin-1", errors="ignore").strip()


def extract_text(filename: str, file_bytes: bytes) -> str:
    lower = filename.lower()
    if lower.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes)
    if lower.endswith((".eml", ".txt", ".msg")):
        return extract_text_from_email(file_bytes)
    # Fallback: try as plain text
    return extract_text_from_email(file_bytes)
