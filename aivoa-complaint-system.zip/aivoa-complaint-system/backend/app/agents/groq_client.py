"""
Thin wrapper around Groq's chat completion API.

Per the assignment: primary model is `gemma2-9b-it`, with
`llama-3.3-70b-versatile` available for tasks that need more context/reasoning
(e.g. summarization or root-cause suggestions over longer complaint text).
"""
import os
import json
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

_client = None


def get_client() -> Groq:
    global _client
    if _client is None:
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise RuntimeError(
                "GROQ_API_KEY is not set. Copy backend/.env.example to backend/.env "
                "and add your key from https://console.groq.com/keys"
            )
        _client = Groq(api_key=api_key)
    return _client


PRIMARY_MODEL = os.getenv("GROQ_PRIMARY_MODEL", "gemma2-9b-it")
CONTEXT_MODEL = os.getenv("GROQ_CONTEXT_MODEL", "llama-3.3-70b-versatile")


def call_llm_json(system_prompt: str, user_prompt: str, model: str = PRIMARY_MODEL, temperature: float = 0.2) -> dict:
    """Call the LLM and parse a JSON object out of the response.

    We ask the model to reply with JSON only, then defensively strip code
    fences / stray text before parsing, since smaller models don't always
    obey formatting instructions perfectly.
    """
    client = get_client()
    completion = client.chat.completions.create(
        model=model,
        temperature=temperature,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    )
    raw = completion.choices[0].message.content.strip()
    raw = raw.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Last resort: try to find the first {...} block in the text
        start, end = raw.find("{"), raw.rfind("}")
        if start != -1 and end != -1:
            try:
                return json.loads(raw[start:end + 1])
            except json.JSONDecodeError:
                pass
        return {"_raw_response": raw, "_parse_error": True}
