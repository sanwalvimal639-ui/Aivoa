"""
ORM models.

Field choices are informed by how a pharma QMS Customer Complaint module
actually works (21 CFR 211.198 / ICH Q10 style complaint handling):
a complaint has an intake record, a risk/severity classification, an
investigation + root cause, and a CAPA (Corrective and Preventive Action)
outcome, moving through a defined status lifecycle.
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import Column, String, Text, DateTime, Enum, Float, ForeignKey
from sqlalchemy.orm import relationship

from app.database import Base


def gen_uuid():
    return str(uuid.uuid4())


class ComplaintStatus(str, enum.Enum):
    NEW = "New"
    UNDER_REVIEW = "Under Review"
    INVESTIGATION = "Investigation"
    CAPA_PROPOSED = "CAPA Proposed"
    CLOSED = "Closed"


class RiskLevel(str, enum.Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"


class ProductType(str, enum.Enum):
    API = "API"          # Active Pharmaceutical Ingredient
    FDF = "FDF"           # Finished Dosage Form


class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(String, primary_key=True, default=gen_uuid)
    complaint_number = Column(String, unique=True, index=True)  # e.g. CMP-2026-0001

    # --- Intake (what the customer/user submitted) ---
    customer_name = Column(String, nullable=True)
    product_name = Column(String, nullable=True)
    product_type = Column(Enum(ProductType), nullable=True)
    batch_number = Column(String, nullable=True)
    complaint_text = Column(Text, nullable=False)      # raw narrative (typed, or extracted from PDF/email)
    source_channel = Column(String, default="manual")  # manual | pdf | email | prompt

    # --- AI Copilot Risk Assessment output ---
    risk_level = Column(Enum(RiskLevel), nullable=True)
    risk_rationale = Column(Text, nullable=True)
    completeness_score = Column(Float, nullable=True)     # 0-100, from Completeness Checker
    missing_fields = Column(Text, nullable=True)           # JSON-encoded list
    ai_summary = Column(Text, nullable=True)                # Complaint Summary bonus feature
    root_cause_suggestion = Column(Text, nullable=True)     # Root Cause Recommendation bonus feature
    capa_suggestion = Column(Text, nullable=True)           # CAPA Recommendation bonus feature
    possible_duplicate_of = Column(String, nullable=True)   # complaint_number of likely duplicate

    # --- Workflow state ---
    status = Column(Enum(ComplaintStatus), default=ComplaintStatus.NEW)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    events = relationship("ComplaintEvent", back_populates="complaint", cascade="all, delete-orphan")


class ComplaintEvent(Base):
    """Simple audit trail — every AI step and status change gets logged here,
    which is exactly the kind of traceability a real QMS requires."""
    __tablename__ = "complaint_events"

    id = Column(String, primary_key=True, default=gen_uuid)
    complaint_id = Column(String, ForeignKey("complaints.id"))
    event_type = Column(String)     # e.g. "ai_risk_assessment", "status_change"
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    complaint = relationship("Complaint", back_populates="events")
