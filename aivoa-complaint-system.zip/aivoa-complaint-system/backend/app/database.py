"""
Database engine + session setup.

Defaults to a local SQLite file so the app runs out-of-the-box with zero
setup. Point DATABASE_URL at Postgres/MySQL (per the assignment's mandatory
stack) for anything beyond local demoing:

    DATABASE_URL=postgresql://user:pass@localhost:5432/aivoa_complaints
"""
import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./complaints.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency: yields a DB session and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
