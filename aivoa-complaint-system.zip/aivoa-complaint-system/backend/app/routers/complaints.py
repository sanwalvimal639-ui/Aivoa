"""
Complaint API routes.

Frontend workflow this supports (matches the demo's end-to-end flow):

1. User types a prompt OR uploads a PDF/email  ─▶  POST /complaints/analyze
   Runs the LangGraph AI Copilot pipeline and returns structured fields +
   risk assessment WITHOUT saving anything yet — this is what pre-fills the
   "Log Customer Complaint" form and the "AI Copilot Risk Assessment" panel
   for the user to review/edit before submitting.

2. User reviews/edits the pre-filled form and submits  ─▶  POST /complaints
   Persists the (possibly edited) complaint + AI outputs to the database.

3. Complaint list / detail / status updates for the QMS workflow.
"""
import json
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database import get_db
from app.models.complaint import Complaint, ComplaintEvent, ComplaintStatus
from app.schemas import ComplaintCreate, ComplaintOut, RiskAssessmentOut, StatusUpdate, ExtractedTextIn
from app.agents.complaint_agent import run_complaint_agent
from app.agents.document_parser import extract_text

router = APIRouter(prefix="/complaints", tags=["complaints"])


def _next_complaint_number(db: Session) -> str:
    year = datetime.utcnow().year
    count = db.query(func.count(Complaint.id)).scalar() or 0
    return f"CMP-{year}-{count + 1:04d}"


def _recent_complaints_as_dicts(db: Session, limit: int = 15) -> List[dict]:
    rows = db.query(Complaint).order_by(Complaint.created_at.desc()).limit(limit).all()
    return [
        {
            "complaint_number": r.complaint_number,
            "product_name": r.product_name,
            "batch_number": r.batch_number,
            "complaint_text": r.complaint_text,
        }
        for r in rows
    ]


@router.post("/analyze", response_model=dict)
def analyze_text(payload: ExtractedTextIn, db: Session = Depends(get_db)):
    """Run the AI Copilot on typed/pasted text. Returns structured fields +
    risk assessment to pre-fill the frontend form — nothing is saved yet."""
    if not payload.raw_text.strip():
        raise HTTPException(status_code=400, detail="raw_text is required")

    existing = _recent_complaints_as_dicts(db)
    result = run_complaint_agent(payload.raw_text, existing_complaints=existing)
    return result


@router.post("/analyze-file", response_model=dict)
async def analyze_file(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Same as /analyze, but the source is an uploaded PDF or email file.
    This is what powers the 'upload PDF/email' entry point in the demo."""
    file_bytes = await file.read()
    raw_text = extract_text(file.filename, file_bytes)
    if not raw_text.strip():
        raise HTTPException(status_code=422, detail="Could not extract any text from the uploaded file")

    existing = _recent_complaints_as_dicts(db)
    result = run_complaint_agent(raw_text, existing_complaints=existing)
    result["_source_channel"] = "pdf" if file.filename.lower().endswith(".pdf") else "email"
    return result


@router.post("", response_model=ComplaintOut)
def create_complaint(payload: ComplaintCreate, db: Session = Depends(get_db)):
    """Persist a complaint. Typically called after the user reviews the
    AI-prefilled form from /analyze — but works standalone for a fully
    manual entry too."""
    complaint = Complaint(
        complaint_number=_next_complaint_number(db),
        customer_name=payload.customer_name,
        product_name=payload.product_name,
        product_type=payload.product_type,
        batch_number=payload.batch_number,
        complaint_text=payload.complaint_text,
        source_channel=payload.source_channel or "manual",
        status=ComplaintStatus.NEW,
    )
    db.add(complaint)
    db.commit()
    db.refresh(complaint)

    db.add(ComplaintEvent(
        complaint_id=complaint.id,
        event_type="created",
        description=f"Complaint {complaint.complaint_number} logged via {complaint.source_channel}.",
    ))
    db.commit()

    # Run the AI Copilot again against the final saved text so the stored
    # risk assessment reflects exactly what was submitted (in case the user
    # edited the AI-suggested fields before saving).
    existing = _recent_complaints_as_dicts(db)
    ai_result = run_complaint_agent(complaint.complaint_text, existing_complaints=existing)

    complaint.risk_level = ai_result.get("risk_level")
    complaint.risk_rationale = ai_result.get("risk_rationale")
    complaint.completeness_score = ai_result.get("completeness_score")
    complaint.missing_fields = json.dumps(ai_result.get("missing_fields") or [])
    complaint.ai_summary = ai_result.get("ai_summary")
    complaint.root_cause_suggestion = ai_result.get("root_cause_suggestion")
    complaint.capa_suggestion = ai_result.get("capa_suggestion")
    complaint.possible_duplicate_of = ai_result.get("possible_duplicate_of")
    db.commit()
    db.refresh(complaint)

    db.add(ComplaintEvent(
        complaint_id=complaint.id,
        event_type="ai_risk_assessment",
        description=f"AI Copilot assessed risk as {complaint.risk_level}: {complaint.risk_rationale}",
    ))
    db.commit()

    return complaint


@router.get("", response_model=List[ComplaintOut])
def list_complaints(status: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(Complaint).order_by(Complaint.created_at.desc())
    if status:
        query = query.filter(Complaint.status == status)
    return query.all()


@router.get("/{complaint_id}", response_model=ComplaintOut)
def get_complaint(complaint_id: str, db: Session = Depends(get_db)):
    complaint = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not complaint:
        raise HTTPException(status_code=404, detail="Complaint not found")
    return complaint


@router.patch("/{complaint_id}/status", response_model=ComplaintOut)
def update_status(complaint_id: str, payload: StatusUpdate, db: Session = Depends(get_db)):
    complaint = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not complaint:
        raise HTTPException(status_code=404, detail="Complaint not found")
    if payload.status not in [s.value for s in ComplaintStatus]:
        raise HTTPException(status_code=400, detail=f"Invalid status: {payload.status}")

    old_status = complaint.status
    complaint.status = payload.status
    db.commit()
    db.refresh(complaint)

    db.add(ComplaintEvent(
        complaint_id=complaint.id,
        event_type="status_change",
        description=f"Status changed from {old_status} to {payload.status}.",
    ))
    db.commit()
    return complaint
