# AIVOA — AI-Powered Customer Complaint Management System

Built for the AIVOA Round 1 AI Product Engineer (Interns) assignment.
An AI-assisted intake and risk-assessment system for pharmaceutical
customer complaints (API / FDF products).

> ⚠️ **Before you submit anything:** this scaffold was built from the
> assignment doc alone — I have not seen the actual demo video or reference
> UI screenshots referenced in the doc. You (the person doing this
> assignment) MUST:
> 1. Watch the demo video and compare its exact workflow against what's here.
> 2. Adjust field names, screens, and the agent pipeline to match what's shown.
> 3. Actually read and understand every file below before you submit — you
>    need to be able to explain and modify all of it in the interview.
>
> Treat this as a strong, working starting point — not a finished, blind
> submission.

---

## What's implemented

**Core workflow** (matches the deliverables' description: *"user's input
(prompt or PDF/email upload) → frontend → API endpoints → backend
processing → AI/LangGraph workflow → Log Customer Complaint form → AI
Copilot Risk Assessment"*):

1. User types a complaint description, or uploads a PDF/email, in **New
   Complaint Intake**.
2. Frontend calls `POST /complaints/analyze` (text) or
   `POST /complaints/analyze-file` (file upload).
3. Backend extracts text (pypdf for PDFs) and runs it through a
   **LangGraph** agent (`backend/app/agents/complaint_agent.py`) with 6
   sequential nodes, each calling Groq's `gemma2-9b-it` (or
   `llama-3.3-70b-versatile` for the reasoning-heavier nodes).
4. The AI's structured output pre-fills the **Log Customer Complaint**
   form (Redux state) and populates the **AI Copilot Risk Assessment**
   panel.
5. User reviews/edits the pre-filled form, submits → `POST /complaints`
   persists it to the database, re-running the AI pass on the final text.
6. **Complaint Log** lists everything with status management
   (New → Under Review → Investigation → CAPA Proposed → Closed — a
   simplified real-world QMS complaint lifecycle).

**Bonus AI features implemented** (all from the assignment's suggested list):
| Feature | Where |
|---|---|
| Complaint Completeness Checker | `completeness_check` node |
| AI Risk Classification | `risk_classification` node |
| Duplicate Complaint Detection | `duplicate_check` node |
| Root Cause Recommendation | `root_cause_and_capa` node |
| CAPA Recommendation | `root_cause_and_capa` node |
| Complaint Summary | `summarize` node |

## Why these design choices (for your interview)

- **QMS complaint lifecycle**: fields and statuses are modeled loosely on
  how complaint handling actually works under 21 CFR 211.198 / ICH Q10 —
  intake → risk triage → investigation → CAPA → closure — since the
  assignment explicitly asks you to research this.
- **API vs FDF**: Active Pharmaceutical Ingredient vs Finished Dosage Form
  — the two manufacturing contexts named in the assignment. Product type
  is captured because root-cause/risk reasoning genuinely differs between
  them (e.g. an FDF discoloration complaint vs an API purity complaint).
- **LangGraph as a linear pipeline, not a router**: each node has one job
  and passes state forward. This is easy to explain, easy to extend (e.g.
  add a conditional branch that skips root-cause suggestion for Low-risk
  complaints), and keeps prompts small and auditable — every AI decision
  writes an event to `ComplaintEvent` for traceability, which real QMS
  systems require.
- **Two-phase AI run** (`/analyze` before save, then re-run on submit):
  lets a human correct the AI's extraction before it's committed, while
  guaranteeing the *persisted* risk assessment matches the *final*
  complaint text — not a stale pre-edit version.
- **Groq model split**: `gemma2-9b-it` (fast/cheap) for extraction,
  completeness, classification, duplicate-check, and summary; the larger
  `llama-3.3-70b-versatile` only for root-cause/CAPA suggestions, which
  benefit most from stronger reasoning.

## Project structure

```
backend/
  app/
    main.py              FastAPI app + CORS + table creation
    database.py           SQLAlchemy engine/session (SQLite by default)
    schemas.py             Pydantic request/response models
    models/complaint.py    ORM models: Complaint, ComplaintEvent
    routers/complaints.py  All API routes
    agents/
      groq_client.py        Groq API wrapper
      complaint_agent.py    The LangGraph agent (6 nodes)
      document_parser.py    PDF/email → text extraction
  requirements.txt
  .env.example

frontend/
  src/
    App.js                Layout
    store/                Redux Toolkit slice + store
    api/api.js             Axios client
    components/
      ComplaintIntake.js       Prompt box + file upload → triggers AI Copilot
      ComplaintForm.js          "Log Customer Complaint" form
      RiskAssessmentPanel.js    "AI Copilot Risk Assessment" panel
      ComplaintList.js          Complaint log + status workflow
  package.json

sample_complaints/       Sample text you can use to demo the workflow
```

## Running it locally

### 1. Backend

```bash
cd backend
python3 -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt

cp .env.example .env
# edit .env: add your GROQ_API_KEY from https://console.groq.com/keys
# (DATABASE_URL defaults to a local sqlite file — fine for the demo;
#  swap in a real Postgres URL to match the mandatory stack for submission)

uvicorn app.main:app --reload --port 8000
```

API docs at `http://localhost:8000/docs` (FastAPI's auto-generated Swagger UI).

### 2. Frontend

```bash
cd frontend
npm install
npm start
```

Opens at `http://localhost:3000`.

### 3. Try it

- Paste text from `sample_complaints/sample_prompt_high_risk.txt` into
  **New Complaint Intake** → click **Run AI Copilot** → watch the AI Copilot
  Risk Assessment panel and the Log Customer Complaint form populate.
- Upload `sample_complaints/sample_email_complaint.txt` as a file to see
  the same flow via the upload path.
- Submit the complaint, then open it in the Complaint Log and change its
  status to walk through the QMS lifecycle.
- Submit a second, similar complaint (same product/batch) to see the
  Duplicate Complaint Detection feature flag it.

## What you still need to do before submitting

1. **Watch the actual demo video** and adjust the workflow/UI/field names
   to match exactly what it shows — I built this from the written spec only.
2. **Match the reference UI** as closely as you want (doc says it doesn't
   need to match exactly, but functionality should).
3. **Switch to Postgres/MySQL** for the submission (currently defaults to
   SQLite for zero-setup local dev — just change `DATABASE_URL` in `.env`).
4. **Add your own realistic sample PDFs/emails/images** as the doc suggests
   — the `.txt` samples here are a starting point.
5. **Record your two demo videos** walking through the code end-to-end,
   per the deliverables section.
6. **Read every file above** until you can explain and modify it live —
   the interview will test this directly.
